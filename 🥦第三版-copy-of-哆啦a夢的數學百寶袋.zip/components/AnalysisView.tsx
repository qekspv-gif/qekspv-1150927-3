import React, { useState, useMemo, useEffect, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { UploadedFile, AnalysisItem } from '../types';

// Declare window interface for PDF.js
declare global {
  interface Window {
    pdfjsLib: any;
  }
}

// Initialize PDF Worker if library is available
if (typeof window !== 'undefined' && window.pdfjsLib) {
  window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

interface AnalysisViewProps {
  analysisItems: AnalysisItem[];
  onReset: () => void;
  files: UploadedFile[];
  onContinuePage: (page: number) => void;
}

// --- Custom Animation Component: Doraemon's Pocket ---
const DoraemonPocketLoading = ({ small = false }: { small?: boolean }) => (
  <div className={`flex flex-col items-center justify-center ${small ? 'gap-2' : 'py-10 gap-6'}`}>
    <style dangerouslySetInnerHTML={{__html: `
      @keyframes rummage {
        0% { transform: rotate(0deg) scale(1); }
        25% { transform: rotate(3deg) scale(1.02); }
        50% { transform: rotate(-3deg) scale(0.98); }
        75% { transform: rotate(2deg) scale(1.01); }
        100% { transform: rotate(0deg) scale(1); }
      }
      @keyframes pop-item {
        0% { opacity: 0; transform: translate(-50%, 20px) scale(0.5); }
        50% { opacity: 1; transform: translate(-50%, -40px) scale(1.2); }
        100% { opacity: 0; transform: translate(-50%, -60px) scale(0.8); }
      }
      @keyframes hand-move {
        0% { transform: translate(-50%, 0); }
        50% { transform: translate(-50%, 5px); }
        100% { transform: translate(-50%, 0); }
      }
      .pocket-rummage { animation: rummage 0.8s ease-in-out infinite; }
      .item-pop-1 { animation: pop-item 2s ease-out infinite; animation-delay: 0s; }
      .item-pop-2 { animation: pop-item 2s ease-out infinite; animation-delay: 0.6s; }
      .item-pop-3 { animation: pop-item 2s ease-out infinite; animation-delay: 1.2s; }
      
      .pocket-sm { width: 40px; height: 25px; }
      .pocket-lg { width: 128px; height: 80px; }
    `}} />
    
    <div className={`relative ${small ? 'w-10 h-6' : 'w-32 h-20'}`}>
      {/* Flying Items */}
      {!small && (
        <>
            <div className="absolute top-0 left-1/2 text-3xl item-pop-1">🚁</div>
            <div className="absolute top-0 left-1/2 text-3xl item-pop-2">🔦</div>
            <div className="absolute top-0 left-1/2 text-3xl item-pop-3">🍞</div>
        </>
      )}

      {/* Pocket Body */}
      <div className={`absolute bottom-0 left-0 bg-white border-blue-500 rounded-b-full shadow-lg pocket-rummage overflow-hidden z-10 ${small ? 'w-10 h-6 border-2' : 'w-32 h-20 border-4'}`}>
         {/* Hand (Circle) */}
         <div className={`absolute left-1/2 bg-red-500 rounded-full border-red-700 shadow-inner animate-[hand-move_0.5s_infinite] ${small ? '-top-1 w-4 h-4 border' : '-top-4 w-12 h-12 border-2'}`}></div>
      </div>
    </div>
    
    <p className={`font-bold text-blue-600 animate-pulse tracking-wide ${small ? 'text-sm' : 'text-xl'}`}>
      {small ? '正在翻找...' : '哆啦A夢正在翻找資料...'}
    </p>
  </div>
);

export const AnalysisView: React.FC<AnalysisViewProps> = ({ analysisItems, onReset, files, onContinuePage }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [isAnalyzingMore, setIsAnalyzingMore] = useState(false);
  const [analyzingNextPage, setAnalyzingNextPage] = useState(false);
  const [pdfTotalPages, setPdfTotalPages] = useState<number | null>(null);
  
  // Track dismissed prompts per page to allow user to say "No"
  const [dismissedPrompts, setDismissedPrompts] = useState<Record<number, boolean>>({});

  // State for toggling extra questions
  const [activeExtra, setActiveExtra] = useState<'none' | 'scaffolding' | 'literacy'>('none');

  const currentItem = analysisItems[currentIndex];
  const totalItems = analysisItems.length;

  // Determine actual render page (Clamped)
  const renderPageNum = useMemo(() => {
    if (!currentItem) return 1;
    let pageNum = currentItem.page;
    // If PDF and we know total pages, clamp it
    if (pdfTotalPages && pageNum > pdfTotalPages) {
        // If currentItem.page is 68 but PDF has 14 pages, we assume the user is looking at the LAST page 
        // OR we can't really know. But for rendering, we must clamp.
        // However, this mismatch is what caused the bug. 
        // We will return the clamped value for rendering.
        return pdfTotalPages;
    }
    // If pageNum is 0 or negative
    if (pageNum < 1) return 1;
    return pageNum;
  }, [currentItem, pdfTotalPages]);

  // Determine if this is the last item for the current *Logical* page
  // We use currentItem.page to group items
  const isLastItemOfPage = useMemo(() => {
    if (!currentItem) return false;
    const nextItem = analysisItems[currentIndex + 1];
    return !nextItem || nextItem.page !== currentItem.page;
  }, [currentIndex, analysisItems, currentItem]);

  // File Selection Logic
  const targetFile = useMemo(() => {
    if (!files || files.length === 0) return null;
    let targetIndex = 0;
    if (files.length > 1) {
        // If multiple files (Images), map page to file index
        if (currentItem && typeof currentItem.page === 'number') {
            const pageNum = Math.max(1, currentItem.page);
            targetIndex = pageNum - 1;
        }
    } else {
        targetIndex = 0;
    }
    if (targetIndex < 0) targetIndex = 0;
    if (targetIndex >= files.length) targetIndex = files.length - 1;
    return files[targetIndex];
  }, [files, currentItem]);

  const isPdf = targetFile?.mimeType === 'application/pdf';

  // Determine what to show for total pages in Header
  const displayTotalPages = useMemo(() => {
     if (isPdf && pdfTotalPages) return pdfTotalPages;
     return files.length;
  }, [isPdf, pdfTotalPages, files.length]);

  // Determine if there is a next page available
  const hasNextPageFile = useMemo(() => {
    if (!currentItem || files.length === 0) return false;
    const totalAvailablePages = (isPdf && pdfTotalPages) ? pdfTotalPages : files.length;
    
    // We use the RENDERED page number to check "Next Page", 
    // because currentItem.page might be 68 (wrong).
    if (currentIndex === totalItems - 1) {
        return renderPageNum < totalAvailablePages;
    }
    return false;
  }, [currentIndex, totalItems, currentItem, files.length, isPdf, pdfTotalPages, renderPageNum]);

  // Content Parsing Logic: Separate Problem from Analysis
  const parsedContent = useMemo(() => {
    if (!currentItem?.content) return null;
    const splitKey = '### 🎯 哆啦A夢分析';
    if (currentItem.content.includes(splitKey)) {
        const parts = currentItem.content.split(splitKey);
        let problem = parts[0].replace(/### 題目內容/g, '').trim();
        let analysis = parts[1].trim();
        return { isStructured: true, problem, analysis };
    }
    return { isStructured: false, raw: currentItem.content };
  }, [currentItem]);

  // Reset extra view when changing items
  useEffect(() => {
    setActiveExtra('none');
  }, [currentIndex]);

  // Handle triggering analyze more for CURRENT PAGE
  const handleAnalyzeMoreClick = async () => {
    if (!currentItem) return;
    try {
        setIsAnalyzingMore(true);
        await new Promise(r => setTimeout(r, 100));
        // FIX: Pass 'renderPageNum' (the actual visible PDF page) instead of 'currentItem.page' (which might be 68)
        await onContinuePage(renderPageNum);
    } catch (error) {
        console.error("Failed to analyze more:", error);
        alert("啟動失敗，請再試一次");
    } finally {
        setIsAnalyzingMore(false);
    }
  };

  // Handle triggering analyze for NEXT PAGE
  const handleAnalyzeNextPageClick = async () => {
    if (!currentItem) return;
    const nextPage = renderPageNum + 1;
    try {
        setAnalyzingNextPage(true);
        await new Promise(r => setTimeout(r, 100));
        await onContinuePage(nextPage);
    } catch (error) {
        console.error("Failed to analyze next page:", error);
        alert("啟動失敗，請再試一次");
    } finally {
        setAnalyzingNextPage(false);
    }
  };

  const handleDismissPrompt = () => {
      if(currentItem) {
          setDismissedPrompts(prev => ({...prev, [currentItem.page]: true}));
      }
  };

  // Helper to draw bounding box
  const drawBoundingBox = (ctx: CanvasRenderingContext2D, width: number, height: number, box?: number[]) => {
      if (!box || box.length !== 4) return;
      const [ymin, xmin, ymax, xmax] = box;
      const x = (xmin / 1000) * width;
      const y = (ymin / 1000) * height;
      const w = ((xmax - xmin) / 1000) * width;
      const h = ((ymax - ymin) / 1000) * height;

      ctx.beginPath();
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#ef4444'; 
      ctx.setLineDash([15, 10]); 
      ctx.rect(x, y, w, h);
      ctx.stroke();
      ctx.fillStyle = 'rgba(239, 68, 68, 0.15)';
      ctx.fill();
      ctx.setLineDash([]);
  };

  // Rendering Effect (Unified for PDF and Image)
  useEffect(() => {
    let renderTask: any = null;
    let isActive = true;
    
    const renderContent = async () => {
      if (!targetFile || !canvasRef.current) return;
      setRenderError(null);
      
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      try {
        if (isPdf) {
            // --- PDF Rendering ---
            if (!window.pdfjsLib) {
                setRenderError("PDF 核心模組未載入");
                return;
            }

            const loadingTask = window.pdfjsLib.getDocument(targetFile.data);
            const pdf = await loadingTask.promise;
            
            if (!isActive) return;
            setPdfTotalPages(pdf.numPages);

            // Use calculated renderPageNum instead of raw item page
            const page = await pdf.getPage(renderPageNum);
            if (!isActive) return;

            const scale = 1.5; 
            const viewport = page.getViewport({ scale });
            canvas.height = viewport.height;
            canvas.width = viewport.width;

            const renderContext = {
                canvasContext: ctx,
                viewport: viewport,
            };
            
            if (renderTask && renderTask.cancel) {
                try { renderTask.cancel(); } catch(e) {}
            }

            renderTask = page.render(renderContext);
            await renderTask.promise;
            
            if (isActive) {
                drawBoundingBox(ctx, viewport.width, viewport.height, currentItem?.boundingBox);
            }

        } else {
            // --- Image Rendering ---
            setPdfTotalPages(null); 
            const img = new Image();
            img.src = targetFile.data;
            await new Promise((resolve, reject) => {
                img.onload = resolve;
                img.onerror = reject;
            });

            if (!isActive) return;
            canvas.width = img.width;
            canvas.height = img.height;
            ctx.drawImage(img, 0, 0);
            drawBoundingBox(ctx, img.width, img.height, currentItem?.boundingBox);
        }

      } catch (error: any) {
        if (error?.name === 'RenderingCancelledException') return;
        console.error("Render Failed:", error);
        if (isActive) setRenderError("無法預覽內容");
      }
    };

    const timeoutId = setTimeout(renderContent, 50);
    return () => {
        clearTimeout(timeoutId);
        isActive = false;
        if (renderTask && renderTask.cancel) renderTask.cancel();
    };
  }, [targetFile, renderPageNum, isPdf, currentItem]); // Updated dependency to renderPageNum

  return (
    <div className="animate-fade-in-up h-[85vh] flex flex-col">
      {/* Top Navigation Bar */}
      <div className="bg-blue-600 rounded-2xl p-4 mb-4 shadow-lg border border-blue-500 flex items-center justify-between shrink-0 text-white">
         <div className="flex items-center gap-4">
             <button onClick={onReset} className="text-blue-100 hover:text-yellow-300 font-bold text-sm flex items-center gap-1 transition-colors">
               ⬅ 收起道具
             </button>
             <div className="h-8 w-px bg-blue-400"></div>
             <div>
                <h2 className="font-black text-white text-lg md:text-xl">{currentItem?.title || '分析結果'}</h2>
                <div className="text-xs text-blue-200 font-bold flex items-center gap-2">
                  {/* Show Rendered Page Number to be consistent */}
                  <span>第 {renderPageNum} / {displayTotalPages} 頁</span>
                  <span className="w-1 h-1 rounded-full bg-blue-300"></span>
                  <span>{currentItem?.problemId ? `布題 ${currentItem.problemId}` : '補充練習'}</span>
                </div>
             </div>
         </div>

         <div className="flex items-center gap-2">
            <button 
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(c => Math.max(0, c - 1))}
              className={`p-2 rounded-full border ${currentIndex === 0 ? 'border-blue-400 text-blue-400' : 'bg-white border-white text-blue-600 hover:bg-yellow-100 hover:text-blue-700 hover:border-yellow-300'} transition-all`}
            >
              ◀
            </button>
            <span className="font-mono font-bold text-blue-100 bg-blue-700 px-3 py-1 rounded-lg">
              {currentIndex + 1} / {totalItems}
            </span>
            <button 
              disabled={currentIndex === totalItems - 1}
              onClick={() => setCurrentIndex(c => Math.min(totalItems - 1, c + 1))}
              className={`p-2 rounded-full border ${currentIndex === totalItems - 1 ? 'border-blue-400 text-blue-400' : 'bg-white border-white text-blue-600 hover:bg-yellow-100 hover:text-blue-700 hover:border-yellow-300'} transition-all`}
            >
              ▶
            </button>
         </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 flex-grow overflow-hidden">
        
        {/* Left Column: Source Material */}
        <div className="lg:w-1/2 flex flex-col h-full gap-4">
            <div className="bg-white rounded-2xl p-2 shadow-inner border-2 border-blue-100 flex-grow relative overflow-hidden flex flex-col h-full">
               
               {/* Label */}
               <div className="absolute top-0 right-0 z-10 bg-blue-500/90 backdrop-blur text-white text-[10px] px-3 py-1 rounded-bl-xl font-bold uppercase tracking-wider shadow">
                 SOURCE: {isPdf ? 'PDF DOC' : 'IMAGE'}
               </div>

               <div className="flex-grow bg-slate-100 rounded-xl flex items-center justify-center overflow-auto relative custom-scrollbar border border-slate-200">
                 {targetFile ? (
                    <div className="relative min-w-[300px] min-h-[400px] flex items-center justify-center p-4">
                        {/* Unified Canvas */}
                        <canvas ref={canvasRef} className="max-w-full shadow-2xl rounded" />
                        
                        {renderError && (
                            <div className="absolute inset-0 flex items-center justify-center bg-white/90 p-4">
                                <span className="text-red-500 font-bold text-center">{renderError}</span>
                            </div>
                        )}
                    </div>
                 ) : (
                     <div className="text-slate-400 text-center p-4">
                        <div className="text-4xl mb-2 opacity-50">📄</div>
                        <p>空白...</p>
                     </div>
                 )}
               </div>
            </div>
        </div>

        {/* Right Column: Analysis Content */}
        <div className="lg:w-1/2 h-full flex flex-col gap-4">
          <div className="bg-white border border-blue-100 rounded-3xl p-6 shadow-xl relative flex-grow overflow-hidden flex flex-col ring-4 ring-blue-50">
            <div className="overflow-y-auto flex-grow pr-2 custom-scrollbar flex flex-col">
              
              {/* Main Analysis Content */}
              {currentItem?.content ? (
                 parsedContent?.isStructured ? (
                    <div className="flex flex-col gap-6 mb-6">
                        {/* Section 1: Problem Content */}
                        <div className="bg-white rounded-2xl p-5 border-2 border-slate-100 shadow-sm relative overflow-hidden group hover:border-blue-200 transition-colors">
                             <div className="absolute top-0 left-0 w-1.5 h-full bg-blue-400"></div>
                             {/* INCREASED PADDING HERE (pl-5) to fix visual offset with the blue bar */}
                             <h3 className="text-xl font-black text-blue-600 mb-3 flex items-center gap-2 pl-5">
                                題目內容
                             </h3>
                             {/* INCREASED PADDING HERE (pl-5) */}
                             <div className="prose prose-lg max-w-none text-slate-700 pl-5">
                                 <ReactMarkdown 
                                    remarkPlugins={[remarkMath]} 
                                    rehypePlugins={[rehypeKatex]}
                                 >
                                    {parsedContent.problem}
                                 </ReactMarkdown>
                             </div>
                        </div>

                        {/* Section 2: Analysis */}
                        <div className="bg-gradient-to-br from-blue-50/50 to-white rounded-2xl p-5 border-2 border-blue-100 shadow-md relative overflow-hidden">
                             <div className="absolute -top-2 -right-2 p-4 opacity-10 pointer-events-none transform rotate-12">
                                <span className="text-7xl">🎯</span>
                             </div>
                             <h3 className="text-xl font-black text-blue-600 mb-3 flex items-center gap-2 border-b border-blue-100 pb-2">
                                <span className="text-2xl text-red-500">🎯</span> 哆啦A夢分析
                             </h3>
                             <div className="prose prose-lg max-w-none prose-p:text-slate-800 prose-strong:text-red-600 prose-strong:bg-yellow-100 prose-strong:px-1 prose-strong:rounded">
                                 <ReactMarkdown 
                                    remarkPlugins={[remarkMath]} 
                                    rehypePlugins={[rehypeKatex]}
                                 >
                                    {parsedContent.analysis}
                                 </ReactMarkdown>
                             </div>
                        </div>
                    </div>
                 ) : (
                    // Fallback for unstructured content
                    <div className="prose prose-lg max-w-none prose-headings:text-blue-600 prose-headings:font-black prose-strong:text-red-500 prose-p:text-slate-700 prose-li:text-slate-700 prose-code:text-blue-600 prose-code:bg-blue-50 prose-code:rounded prose-code:px-1 mb-6">
                        <ReactMarkdown 
                            remarkPlugins={[remarkMath]} 
                            rehypePlugins={[rehypeKatex]}
                        >
                            {parsedContent?.raw || ''}
                        </ReactMarkdown>
                    </div>
                 )
              ) : (
                  // Loading State - Centered vertically in the available space
                  <div className="flex-grow flex flex-col justify-center items-center min-h-[400px]">
                     <DoraemonPocketLoading />
                  </div>
              )}

              {/* Extra Features Section (Collapsible) */}
              {(activeExtra !== 'none' && currentItem) && (
                  <div className={`mt-4 rounded-xl p-4 border-2 shadow-inner animate-fade-in-up min-h-[100px] ${
                      activeExtra === 'scaffolding' 
                        ? 'bg-green-50 border-green-200' 
                        : 'bg-indigo-50 border-indigo-200'
                  }`}>
                      <h4 className={`font-black text-lg mb-2 flex items-center gap-2 ${
                          activeExtra === 'scaffolding' ? 'text-green-700' : 'text-indigo-700'
                      }`}>
                          {activeExtra === 'scaffolding' ? '📉 降階提問 (縮小鏡)' : '🚀 素養提問 (放大燈)'}
                      </h4>
                      <div className="prose prose-sm max-w-none prose-p:text-slate-800 prose-li:text-slate-800">
                           <ReactMarkdown
                                remarkPlugins={[remarkMath]} 
                                rehypePlugins={[rehypeKatex]}
                           >
                               {activeExtra === 'scaffolding' 
                                  ? (currentItem.scaffolding || "*(哆啦A夢忘記準備這個道具了，請嘗試重新分析...)*") 
                                  : (currentItem.literacy || "*(哆啦A夢忘記準備這個道具了，請嘗試重新分析...)*")
                               }
                           </ReactMarkdown>
                      </div>
                  </div>
              )}
              
              {/* Continue Analysis Prompt (CURRENT PAGE) */}
              {(currentItem && isLastItemOfPage && !dismissedPrompts[currentItem.page]) && (
                  <div className="mt-8 py-4 border-t border-slate-200 animate-fade-in-up">
                      {isAnalyzingMore ? (
                           <div className="flex items-center justify-center gap-3 text-blue-600 bg-blue-50 px-6 py-4 rounded-xl border border-blue-200 shadow-inner">
                                <DoraemonPocketLoading small />
                           </div>
                      ) : (
                           <div className="flex flex-col sm:flex-row items-center justify-center gap-4 bg-white p-2 rounded-xl">
                               <div className="flex items-center gap-3 group cursor-pointer" onClick={handleAnalyzeMoreClick}>
                                   <div className="text-3xl filter drop-shadow-sm transform group-hover:scale-110 transition-transform">🔍</div>
                                   <div className="text-lg font-bold text-slate-700 group-hover:text-blue-600 transition-colors">
                                       覺得 <span className="text-blue-600 font-black mx-1">第 {renderPageNum} 頁</span> 有遺漏嗎？ <span className="underline decoration-blue-300 underline-offset-4 decoration-2">點此繼續分析本頁</span>
                                   </div>
                               </div>
                               <button 
                                  onClick={handleDismissPrompt}
                                  className="text-slate-300 hover:text-red-400 p-2 rounded-full hover:bg-red-50 transition-colors"
                                  title="隱藏此提示"
                               >
                                  ✕
                               </button>
                           </div>
                      )}
                  </div>
              )}

              {/* Continue Analysis Prompt (NEXT PAGE) */}
              {hasNextPageFile && (
                  <div className="mt-4 py-6 border-t-2 border-dashed border-blue-200 animate-fade-in-up bg-blue-50/50 rounded-2xl p-4">
                      {analyzingNextPage ? (
                           <div className="flex items-center justify-center gap-3 text-blue-600">
                                <DoraemonPocketLoading small />
                                <span className="font-bold">正在前往下一頁...</span>
                           </div>
                      ) : (
                           <div className="text-center">
                               <h3 className="text-lg font-bold text-blue-800 mb-2">還有下一頁喔！</h3>
                               <p className="text-sm text-slate-600 mb-4">目前已分析到第 {renderPageNum} 頁，但檔案總共有 {displayTotalPages} 頁。</p>
                               <button 
                                  onClick={handleAnalyzeNextPageClick}
                                  className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white text-lg font-black py-3 px-8 rounded-full shadow-lg transform hover:scale-105 transition-all active:scale-95 flex items-center justify-center gap-2 mx-auto"
                               >
                                  <span>➡️</span>
                                  繼續分析下一頁 (第 {renderPageNum + 1} 頁)
                               </button>
                           </div>
                      )}
                  </div>
              )}

            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3 justify-center shrink-0">
             <button 
                onClick={() => setActiveExtra(prev => prev === 'scaffolding' ? 'none' : 'scaffolding')}
                className={`flex-1 py-3 px-6 rounded-2xl font-black text-lg transition-all shadow-md flex items-center justify-center gap-2 border-b-4 active:border-b-0 active:translate-y-1 ${
                    activeExtra === 'scaffolding'
                    ? 'bg-green-600 text-white border-green-800 ring-2 ring-green-300'
                    : 'bg-green-100 text-green-700 border-green-300 hover:bg-green-200'
                }`}
             >
                📉 降階提問
             </button>
             
             <button 
                onClick={() => setActiveExtra(prev => prev === 'literacy' ? 'none' : 'literacy')}
                className={`flex-1 py-3 px-6 rounded-2xl font-black text-lg transition-all shadow-md flex items-center justify-center gap-2 border-b-4 active:border-b-0 active:translate-y-1 ${
                    activeExtra === 'literacy'
                    ? 'bg-indigo-600 text-white border-indigo-800 ring-2 ring-indigo-300'
                    : 'bg-indigo-100 text-indigo-700 border-indigo-300 hover:bg-indigo-200'
                }`}
             >
                🚀 素養提問
             </button>
          </div>

        </div>

      </div>
    </div>
  );
};