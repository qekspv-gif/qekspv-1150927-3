import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen bg-blue-50 relative overflow-x-hidden">
      {/* Background decoration: Blue Sky & Clouds */}
      <div className="fixed top-0 left-0 w-full h-full bg-gradient-to-b from-blue-200 to-white z-0"></div>
      
      {/* Decorative Bell */}
      <div className="fixed top-6 right-10 w-24 h-24 bg-yellow-400 rounded-full border-4 border-yellow-600 shadow-xl z-0 animate-float hidden md:block">
         <div className="absolute top-1/2 left-0 w-full h-1 bg-yellow-700/20"></div>
         <div className="absolute top-[60%] left-1/2 transform -translate-x-1/2 w-4 h-4 bg-black rounded-full opacity-80"></div>
      </div>

      {/* Decorative Propeller (Take-copter) */}
      <div className="fixed top-20 -left-10 w-40 h-4 bg-yellow-400 rotate-12 opacity-50 z-0 hidden md:block"></div>

      <header className="relative z-10 pt-4 pb-2 px-4 text-center">
        <h1 className="text-2xl md:text-4xl font-black text-blue-600 tracking-tighter drop-shadow-sm">
          <span className="inline-block mr-2 text-red-500">🔔</span>
          哆啦A夢的
          <span className="text-red-500"> 數學百寶袋</span>
          <span className="block mt-1 md:mt-0 md:inline-block md:ml-4 text-xs md:text-base font-bold text-slate-400 tracking-normal align-middle">
            (優履工作室研發v114-1220b)
          </span>
        </h1>
        <p className="mt-2 text-blue-800 font-bold text-base md:text-lg drop-shadow-sm bg-white/50 inline-block px-4 py-1 rounded-full">
          「真拿你沒辦法，就用這個道具來幫你備課吧！」
        </p>
      </header>

      <main className="relative z-10 container mx-auto px-4 pb-12 max-w-6xl">
        <div className="bg-white/90 backdrop-blur-sm rounded-[2rem] p-4 md:p-6 shadow-[0_20px_50px_-10px_rgba(59,130,246,0.3)] border-4 border-blue-400 ring-4 ring-white">
          {children}
        </div>
      </main>

    </div>
  );
};