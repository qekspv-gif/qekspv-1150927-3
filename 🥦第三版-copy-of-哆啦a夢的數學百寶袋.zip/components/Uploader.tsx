import React, { useCallback } from 'react';
import { UploadedFile } from '../types';

interface UploaderProps {
  onFilesSelected: (files: UploadedFile[]) => void;
}

export const Uploader: React.FC<UploaderProps> = ({ onFilesSelected }) => {
  const handleFileChange = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    const newFiles: UploadedFile[] = [];

    const readFile = (file: File): Promise<UploadedFile> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            resolve({
              id: Math.random().toString(36).substr(2, 9),
              data: reader.result,
              mimeType: file.type
            });
          } else {
            reject(new Error("Failed to read file"));
          }
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    };

    try {
      for (let i = 0; i < files.length; i++) {
        newFiles.push(await readFile(files[i]));
      }
      onFilesSelected(newFiles);
    } catch (error) {
      console.error("Error reading files", error);
      alert("讀取檔案失敗，請重試！");
    }
  }, [onFilesSelected]);

  return (
    <div className="w-full max-w-2xl mx-auto px-4">
      <div className="relative group">
        <div className="absolute -inset-2 bg-gradient-to-r from-blue-400 to-red-400 rounded-[2.5rem] blur opacity-40 group-hover:opacity-75 transition duration-500"></div>
        
        {/* Fourth Dimension Pocket Style Container - Compacted */}
        <div className="relative bg-white ring-4 ring-blue-100 rounded-[2rem] p-6 pt-12 text-center border-b-[10px] border-blue-500/10 hover:border-blue-400 transition-colors shadow-2xl">
          
          <div className="mb-4 bg-blue-100 w-20 h-20 mx-auto rounded-full flex items-center justify-center border-4 border-white shadow-md group-hover:scale-110 transition-transform">
             <span className="text-3xl">🚪</span>
          </div>
          
          <h3 className="text-2xl font-black text-blue-900 mb-2">
            將備課教材放入「四次元百寶袋」
          </h3>
          <p className="text-blue-500 mb-6 font-medium text-base">
            不管是教科書文本、數學題目、我都會幫您解構分析和提供備課指引！
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4">
             {/* File Select Button */}
             <label className="cursor-pointer transform hover:scale-105 transition-transform">
                <span className="bg-gradient-to-b from-red-500 to-red-600 hover:from-red-400 hover:to-red-500 text-white text-lg font-black py-4 px-8 rounded-full shadow-lg border-b-4 border-red-800 active:border-0 active:translate-y-1 flex items-center justify-center gap-2 min-w-[180px]">
                  <span className="text-2xl">📂</span> 選擇檔案
                </span>
                <input 
                   type="file" 
                   multiple 
                   accept="image/*,application/pdf" 
                   className="hidden" 
                   onChange={handleFileChange}
                />
             </label>

             {/* Camera Button */}
             <label className="cursor-pointer transform hover:scale-105 transition-transform">
                <span className="bg-gradient-to-b from-yellow-400 to-yellow-500 hover:from-yellow-300 hover:to-yellow-400 text-yellow-900 text-lg font-black py-4 px-8 rounded-full shadow-lg border-b-4 border-yellow-700 active:border-0 active:translate-y-1 flex items-center justify-center gap-2 min-w-[180px]">
                  <span className="text-2xl">📸</span> 拍照分析
                </span>
                <input 
                   type="file" 
                   accept="image/*" 
                   capture="environment"
                   className="hidden" 
                   onChange={handleFileChange}
                />
             </label>
          </div>

        </div>
      </div>
    </div>
  );
};