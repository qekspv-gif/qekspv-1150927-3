import { GoogleGenAI } from "@google/genai";
import { ANALYSIS_PROMPT_CONTEXT, CONTINUE_ANALYSIS_PROMPT } from "../constants";
import { UploadedFile, AnalysisItem } from "../types";

export const initGenAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables");
  }
  return new GoogleGenAI({ apiKey });
};

// Safety settings to prevent false positives on textbook content
const SAFETY_SETTINGS = [
  { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
  { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
  { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
  { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
];

const generateWithModel = async (ai: GoogleGenAI, modelId: string, contentParts: any[]) => {
  // Add prompt at the end
  const fullContents = [...contentParts, { text: ANALYSIS_PROMPT_CONTEXT }];
  
  return await ai.models.generateContent({
    model: modelId,
    contents: { parts: fullContents },
    config: {
        // High temperature for creative pedagogical insights
        temperature: 0.7, 
        maxOutputTokens: 8192,
        safetySettings: SAFETY_SETTINGS,
        responseMimeType: "application/json",
        // ENABLE THINKING MODE: Crucial for high-quality analysis
        // This forces the model to "think" about the math problem before outputting JSON.
        thinkingConfig: {
           thinkingBudget: 2048 
        }
    }
  });
};

const cleanAndParseJson = (jsonText: string, fileIndex: number): AnalysisItem[] => {
    jsonText = jsonText.trim();
    if (jsonText.startsWith('```json')) {
        jsonText = jsonText.replace(/^```json\s*/, '').replace(/\s*```$/, '');
    } else if (jsonText.startsWith('```')) {
        jsonText = jsonText.replace(/^```\s*/, '').replace(/\s*```$/, '');
    }
    const startBracket = jsonText.indexOf('[');
    if (startBracket !== -1) {
        jsonText = jsonText.substring(startBracket);
    }

    let items: AnalysisItem[] = [];
    try {
        items = JSON.parse(jsonText) as AnalysisItem[];
    } catch (parseError) {
        console.warn(`JSON Parse failed for File ${fileIndex}, attempting recovery...`);
        // Simple recovery
        let endIdx = jsonText.lastIndexOf('}');
        while (endIdx !== -1) {
            try {
                 const subJson = jsonText.substring(0, endIdx + 1) + ']';
                 const result = JSON.parse(subJson);
                 if (Array.isArray(result)) {
                     items = result;
                     break;
                 }
            } catch(e) {}
            endIdx = jsonText.lastIndexOf('}', endIdx - 1);
        }
    }
    return items;
};

// Helper to normalize content
const normalizeItemContent = (item: any, fileIndex: number, mimeType: string, defaultPage?: number): AnalysisItem => {
    const normalizeContent = (val: any): string | undefined => {
        if (val === undefined || val === null) return undefined;
        if (typeof val === 'string') return val;
        if (Array.isArray(val)) return val.map(String).join('\n');
        return String(val);
    };

    // 1. Clean Content first
    let content = (item.content && typeof item.content === 'string') ? item.content : "";
    
    // Remove accidental Scaffolding/Literacy sections from content
    content = content.replace(/^#{1,4}\s*(降階提問|素養提問).*$/gim, '')
                     .replace(/\*\*(降階提問|素養提問)\*\*.*$/gim, '');

    // Improved Fallback Content - Only show if absolutely empty.
    // With Thinking Mode, this should rarely happen.
    if (content.trim().length < 5 || content.includes("undefined")) {
        content = `### 題目內容\n(題目文字讀取不完整，請參照圖片)\n\n### 🎯 哆啦A夢分析\n**（哆啦A夢正在努力思考中，但這次好像卡住了...）**\n建議老師直接引導學生觀察圖片中的數學關係。`;
    }

    // 2. Intelligent Title Extraction
    if (!item.title || item.title === 'undefined' || item.title.trim() === '') {
        const cleanContent = content
            .replace(/###\s*題目內容/g, '')
            .replace(/###/g, '')
            .replace(/\*\*/g, '')
            .trim();
        
        const firstLine = cleanContent.split('\n')[0].trim();
        
        if (firstLine && firstLine.length > 2) {
             const limit = 30;
             item.title = firstLine.substring(0, limit) + (firstLine.length > limit ? '...' : '');
        } else {
             item.title = ""; 
        }
    }

    // 3. Intelligent Problem ID Extraction
    if (!item.problemId) {
        const titleMatch = item.title.match(/^(\d+)/);
        if (titleMatch) {
            item.problemId = parseInt(titleMatch[1]);
        } else {
             const contentMatch = content.match(/(?:^|\n)(\d+)[.、\s]/);
             if (contentMatch) {
                 item.problemId = parseInt(contentMatch[1]);
             }
        }
    }

    // Fallback for ID
    if (!item.problemId) {
         item.problemId = Math.floor(Math.random() * 1000) + 100;
    }

    // Fallback for Title
    if (!item.title) {
        item.title = `布題 ${item.problemId}`;
    }

    // --- Page Logic ---
    let page = item.page;
    if (defaultPage !== undefined) {
        if (typeof page !== 'number') {
            page = defaultPage;
        } else {
            const diff = Math.abs(page - defaultPage);
            if (diff > 5) { 
                page = defaultPage;
            }
        }
    } else {
        if (typeof page !== 'number') {
             page = fileIndex + 1;
        }
    }
    
    if (!page || page < 1) page = 1;
    item.page = page;

    // Fix Bounding Box
    if (!Array.isArray(item.boundingBox) || item.boundingBox.length !== 4) {
        item.boundingBox = [100, 100, 500, 900];
    }

    return {
        ...item,
        title: item.title,
        content: content,
        scaffolding: normalizeContent(item.scaffolding),
        literacy: normalizeContent(item.literacy),
        visualCue: item.visualCue || "請參照圖片"
    };
};

export const processSingleFile = async (ai: GoogleGenAI, file: UploadedFile, fileIndex: number): Promise<AnalysisItem[]> => {
    const contentParts = [{
        inlineData: {
            mimeType: file.mimeType,
            data: file.data.split(',')[1]
        }
    }];

    let jsonText = "";
    
    try {
        // Strategy: ALWAYS USE PRO MODEL with Thinking Mode.
        // We sacrifice speed for quality as requested.
        console.log(`Processing file ${fileIndex} with Gemini 3 Pro (Thinking Mode)...`);
        
        const response = await generateWithModel(ai, 'gemini-3-pro-preview', contentParts);
        jsonText = response.text || "";
        
        if (!jsonText) throw new Error("Model returned empty text.");

        const items = cleanAndParseJson(jsonText, fileIndex);
        return items.map(item => normalizeItemContent(item, fileIndex, file.mimeType));

    } catch (error) {
        console.error(`Error processing file ${fileIndex}:`, error);
        return [{
            page: fileIndex + 1,
            problemId: 0,
            title: `第 ${fileIndex + 1} 頁分析失敗`,
            content: `哆啦A夢盡力了，但無法讀取這頁的內容。\n錯誤訊息：${error instanceof Error ? error.message : '未知錯誤'}`,
            visualCue: "無",
            boundingBox: [0,0,0,0]
        }];
    }
};

export const analyzeMoreOnPage = async (ai: GoogleGenAI, file: UploadedFile, fileIndex: number, existingItems: AnalysisItem[], pageNumber: number): Promise<AnalysisItem[]> => {
    const existingTitles = existingItems.map(i => i.title).join(", ");
    let prompt = CONTINUE_ANALYSIS_PROMPT
        .replace('{{EXISTING_TITLES}}', existingTitles)
        .replace(/{{PAGE_NUM}}/g, pageNumber.toString());

    const contentParts = [
        {
            inlineData: {
                mimeType: file.mimeType,
                data: file.data.split(',')[1]
            }
        },
        { text: prompt }
    ];

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-preview',
            contents: { parts: contentParts },
            config: {
                temperature: 0.7,
                maxOutputTokens: 8192,
                safetySettings: SAFETY_SETTINGS,
                responseMimeType: "application/json",
                // Thinking mode for Analyze More as well
                thinkingConfig: {
                    thinkingBudget: 2048
                }
            }
        });

        const jsonText = response.text || "";
        if (!jsonText) return [];

        const items = cleanAndParseJson(jsonText, fileIndex);
        return items.map(item => normalizeItemContent(item, fileIndex, file.mimeType, pageNumber));

    } catch (error) {
        console.error("Error analyzing more content:", error);
        return []; 
    }
};

// Deprecated stub
export const analyzeTextbookContent = async (files: UploadedFile[]): Promise<AnalysisItem[]> => {
    return [];
};